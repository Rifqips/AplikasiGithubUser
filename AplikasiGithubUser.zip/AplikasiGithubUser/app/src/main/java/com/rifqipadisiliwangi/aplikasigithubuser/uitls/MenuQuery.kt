package com.rifqipadisiliwangi.aplikasigithubuser.uitls

enum class MenuQuery {
    UPDATE,
    DELETE,
    INSERT
}