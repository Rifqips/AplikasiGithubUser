package com.rifqipadisiliwangi.aplikasigithubuser.model

class Constant {
    companion object{
        const val BACKDROP_PATH = "https://image.tmdb.org/t/p/w500_and_h282_face"
        const val POSTER_PATH   = "https://image.tmdb.org/t/p/w220_and_h330_face"
    }
}