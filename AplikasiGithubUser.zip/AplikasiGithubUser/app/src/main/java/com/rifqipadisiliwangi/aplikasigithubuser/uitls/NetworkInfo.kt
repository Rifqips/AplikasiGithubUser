package com.rifqipadisiliwangi.aplikasigithubuser.uitls


object NetworkInfo {
    const val BASE_URL = "https://api.github.com/"
    const val GITHUB_TOKEN = "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"
}


