package com.rifqipadisiliwangi.aplikasigithubuser.model

data class SearchResponse(
    val items: ArrayList<User>,
)